<?php wp_footer(); ?>
</div> <!-- close main container -->
</body>
</html>